#!/usr/bin/env python3

from service import download_stock

while True:
	cv, id = download_stock()

